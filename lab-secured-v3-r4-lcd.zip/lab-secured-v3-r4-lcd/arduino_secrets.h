// Identifiants du réseau Wi-Fi du labo.
// Ce fichier reste hors du dépôt public (.gitignore).
// Il ne contient ni clé de device, ni certificat, ni adresse du broker.
#pragma once

#define SECRET_SSID "ssid-du-labo"
#define SECRET_PASS "mot-de-passe-du-labo"
