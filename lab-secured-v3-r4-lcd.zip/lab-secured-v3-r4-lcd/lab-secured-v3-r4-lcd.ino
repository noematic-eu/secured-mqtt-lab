// Copyright (c) 2026 Baptiste Boussemart. Tous droits réservés.
// lab-secured-v3 (Arduino UNO R4 WiFi + LCD 16x2 I2C) — la clé naît ici. Le serveur décide de l'enrôlement.
//
// Le sketch public contient le nom (une étiquette) et l'adresse du service
// d'enrôlement. Il ne contient ni clé de device, ni certificat client,
// ni adresse du broker MQTT. Les identifiants Wi-Fi sont dans arduino_secrets.h.
//
//   1. Générer une clé P-256 dans le module ESP32-S3 et un CSR signé par lui.
//      Afficher l'empreinte (SHA-256 du SPKI).
//   2. Envoyer le nom et le CSR en HTTPS. La CA publique est épinglée ci-dessous.
//   3. Attendre. L'administrateur approuve l'empreinte lue sur ce moniteur.
//   4. Recevoir le certificat, la CA et la configuration MQTT. Les garder en RAM.
//   5. Se connecter en mTLS. Le broker applique l'ACL. Une révocation coupe la publication.
//
// Afficheur : LCD 16x2 I2C (PCF8574), voir lcd_status.h pour le câblage.
// Il montre chaque étape, l'empreinte en 4 pages de 16 caractères pour la
// comparaison avec l'administrateur, puis l'état de la session MQTT.
// Sans afficheur, le sketch fonctionne à l'identique sur le moniteur série.
//
// Répartition sur la carte :
//   - RA4M1 (ce sketch) : logique d'enrôlement, JSON, MQTT.
//   - ESP32-S3 (firmware pont >= 0.5.0) : Wi-Fi, TLS, génération de clé,
//     signature ECDSA, stockage de la clé (NVS, espace « se », emplacement KEY_SLOT).
//
// La clé privée ne transite jamais vers le RA4M1 et n'est pas affichée.
// Un reset fabrique une nouvelle clé au même emplacement : l'empreinte précédente
// ne correspond plus.
//
// Limite assumée : le « secure element » de l'UNO R4 WiFi est logiciel. La clé est
// stockée en clair dans la flash de l'ESP32-S3 ; un sketch peut la relire
// (SATSE.readSlot) et un accès physique à la flash la récupère. La protection
// repose sur l'approbation humaine, la durée courte du certificat et la révocation.

#include <WiFiS3.h>
#include <WiFiSSLClient.h>
#include <Arduino_SecureElement.h>
#include <utility/SElementCSR.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <stdarg.h>
#include <time.h>
#include "arduino_secrets.h"
#include "lcd_status.h"


// Certificat public de la CA du labo. Généré par enroll.py pin-ca.
// Il authentifie le serveur d'enrôlement. Ce n'est pas la clé d'un device.
static const char ENROLL_CA_PEM[] =
R"pem(-----BEGIN CERTIFICATE-----
MIIDNTCCAh2gAwIBAgIUCk1ZcxH5OZHEf8vJ1p9YJlGfc3YwDQYJKoZIhvcNAQEL
BQAwIjEgMB4GA1UEAwwXbTJkZnMtc2VjdXJlZC12My1sYWItY2EwHhcNMjYxMTI0
MDA1ODQzWhcNMjcxMTI0MDA1ODQzWjAiMSAwHgYDVQQDDBdtMmRmcy1zZWN1cmVk
LXYzLWxhYi1jYTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMgIT5I+
z/nJ9IaP5cZru+lIiPPFQlvDCG4QrIOaMF/MwA9ckPSayMPwhpdvzzFdW14EK8SX
C7pihsCda1QU7x+pV+moBMUiVCrJXHgs373y0e5vLj2rD7SOfm1dC6EOfuGRXq1p
8EupBvvCO2Brqb6kiQllSsYYgIix9Yl8wlE2/sXKJiII86oDmQACj8HwkQi94e2k
J0FGuHXiLdFhBBOo3pgkO/NBOyYdr94fdoloGGR5+13dVz+nNPYdNcrmSmK/s/ap
ysi8ai2f80IqEWgLIsqdz4nPD3S/MEm/nyX2N6E44c9sosNmGVOOt2XLvTb7zse1
/eCyMu4XZ+IQwgMCAwEAAaNjMGEwHwYDVR0jBBgwFoAUxRyi94UOAc8t0S06NAUk
6CkdmI8wDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYE
FMUcoveFDgHPLdEtOjQFJOgpHZiPMA0GCSqGSIb3DQEBCwUAA4IBAQAQuiN7mb6U
OFkYbJhQaryYIZOiPw50lzb0CjTV2dMrxfQN7LFfEBmSgWzIxC+6YI59tBaqQJLL
WXSLcPjtuczgoXE07zyN34vWS0RKLxoT7+ygSWPGS5AVIz2SuEx1xqWQQxo5wupG
Phd9Xv6q2z5FWQfegrFZnHykpKDUD3SfPsdKdJceGLyrRnzpptkRVAp99waHQXry
Brt2UR1Rkc5H/+pNE0OQep4Uf38Z21wyNP4jmXfbSI+Anxk9qooVXxG2i2CHQD8a
RdccbSjnJOMLtbJIX8XRa2I0XZ6ntGsIUDDZ04f8t+j2aj/K0mB5yZCU+ds+2Tl5
s8qn1f9Yujey
-----END CERTIFICATE-----
)pem";


// Étiquette présentée au serveur. Ce n'est pas un secret.
// Deux sketches avec le même nom : le second est refusé tant que le premier est en cours.
static const char* DEVICE_NAME = "sensor-005";


static const char* ENROLL_HOST = "play.why.noematic.eu";
static const int ENROLL_PORT = 8443;


// Emplacement NVS de la clé dans l'ESP32-S3. Distinct de celui qu'utilise
// Arduino Cloud, pour ne pas écraser une carte déjà provisionnée.
static const int KEY_SLOT = 200;


// Le firmware du pont convertit le certificat client DER en PEM dans un tampon
// de 1024 octets : au-delà d'environ 714 octets DER, setEccSlot échoue.
// Un certificat P-256 signé par la CA RSA-2048 du labo fait environ 630 octets.
static const size_t CLIENT_CERT_DER_MAX = 714;


// Version minimale du firmware ESP32-S3 : 0.4.1 apporte le secure element
// logiciel et setEccSlot, 0.5.0 apporte WiFi.getTime().
static const int FW_MIN_MAJOR = 0, FW_MIN_MINOR = 5, FW_MIN_PATCH = 0;


static const int LED_PIN = LED_BUILTIN;


enum State { ST_BOOT, ST_AWAITING, ST_CONNECTING, ST_ACTIVE, ST_REJECTED };
static State state = ST_BOOT;


static char csrPem[700];
static byte certDer[CLIENT_CERT_DER_MAX];
static size_t certDerLen = 0;
static char caPem[2048];
static char fingerprint[65];
static char mqttHost[64];
static int mqttPort = 0;
static char topicTelemetry[80];
static char topicStatus[80];
static char topicCmd[80];
static char deviceId[40];
static char expiresAt[32];

// Compteurs pour l'afficheur.
static unsigned long pollCount = 0;
static unsigned long publishOk = 0;
static unsigned long publishFail = 0;
static bool lastHttpOk = true;
static bool ledOn = false;

// Réponse HTTP brute. Tampon statique : pas de fragmentation du tas sur 32 Ko.
static char rx[6144];


static WiFiSSLClient net;
static PubSubClient mqtt(net);


static unsigned long lastPoll = 0;
static unsigned long lastTelemetry = 0;
static float temperature = 21.0f;


void onMqttMessage(char* topic, byte* payload, unsigned int length);


// Le Print du cœur Renesas n'a pas de printf.
static void logPrintf(const char* fmt, ...) {
  char buf[192];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  Serial.print(buf);
}


static bool copyText(const char* src, char* dst, size_t dstLen, const char* label) {
  if (src == nullptr || src[0] == '\0') {
    logPrintf("[copie] %s absent\n", label);
    return false;
  }
  size_t n = strlen(src);
  if (n + 1 > dstLen) {
    logPrintf("[copie] %s trop long (%u)\n", label, (unsigned)n);
    return false;
  }
  memcpy(dst, src, n + 1);
  return true;
}


static int b64Value(char c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '+') return 62;
  if (c == '/') return 63;
  return -1;
}


// setEccSlot attend le certificat client en DER : on décode le corps du PEM.
static bool pemToDer(const char* pem, byte* out, size_t outMax, size_t& outLen) {
  const char* begin = strstr(pem, "-----BEGIN CERTIFICATE-----");
  if (begin == nullptr) return false;
  begin = strchr(begin, '\n');
  const char* end = strstr(pem, "-----END CERTIFICATE-----");
  if (begin == nullptr || end == nullptr || end < begin) return false;

  uint32_t acc = 0;
  int bits = 0;
  outLen = 0;
  for (const char* p = begin; p < end; p++) {
    if (*p == '=') break;
    int v = b64Value(*p);
    if (v < 0) continue;  // retours à la ligne, espaces
    acc = (acc << 6) | (uint32_t)v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      if (outLen >= outMax) return false;
      out[outLen++] = (byte)((acc >> bits) & 0xFF);
    }
  }
  return outLen > 0;
}


static bool firmwareRecentEnough() {
  const char* fv = WiFi.firmwareVersion();
  int ma = 0, mi = 0, pa = 0;
  if (fv == nullptr || sscanf(fv, "%d.%d.%d", &ma, &mi, &pa) < 2) {
    Serial.println("[firmware] version ESP32-S3 illisible");
    return false;
  }
  logPrintf("[firmware] ESP32-S3 %s\n", fv);
  lcdui::show("Firmware ESP32", fv);
  long have = ma * 10000L + mi * 100L + pa;
  long need = FW_MIN_MAJOR * 10000L + FW_MIN_MINOR * 100L + FW_MIN_PATCH;
  if (have < need) {
    logPrintf("[firmware] %d.%d.%d minimum requis. Mettez le pont à jour (WIFI_FIRMWARE_LATEST_VERSION = %s).\n",
         FW_MIN_MAJOR, FW_MIN_MINOR, FW_MIN_PATCH, WIFI_FIRMWARE_LATEST_VERSION);
    return false;
  }
  return true;
}


// WiFi.begin() est bloquant sur l'UNO R4 WiFi. On retente l'association
// au lieu de rester sur un seul échec.
static bool connectWiFi() {
  const int MAX_ATTEMPTS = 8;
  for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    if (attempt > 1) {
      WiFi.disconnect();
      delay(500);
    }
    logPrintf("[WiFi] tentative %d/%d ", attempt, MAX_ATTEMPTS);
    char l1[17];
    snprintf(l1, sizeof(l1), "WiFi essai %d/%d", attempt, MAX_ATTEMPTS);
    lcdui::show(l1, SECRET_SSID);
    WiFi.begin(SECRET_SSID, SECRET_PASS);
    unsigned long t0 = millis();
    while (millis() - t0 < 10000 && WiFi.status() != WL_CONNECTED) {
      delay(250);
      Serial.print(".");
    }
    // L'adresse arrive parfois un peu après l'association.
    t0 = millis();
    while (WiFi.status() == WL_CONNECTED && WiFi.localIP() == IPAddress(0, 0, 0, 0) && millis() - t0 < 5000) {
      delay(100);
    }
    if (WiFi.status() == WL_CONNECTED) {
      String ip = WiFi.localIP().toString();
      logPrintf(" OK — IP %s\n", ip.c_str());
      lcdui::show("WiFi connecté", ip.c_str());
      return true;
    }
    Serial.println(" — non connecté, nouvelle tentative");
  }
  return false;
}


// L'ESP32-S3 synchronise lui-même son horloge (SNTP) et s'en sert pour
// contrôler les dates des certificats. On attend qu'elle soit plausible.
static bool clockReady() {
  Serial.print("[NTP] ");
  lcdui::show("Horloge (NTP)", "synchro...");
  for (int i = 0; i < 40; i++) {
    unsigned long epoch = WiFi.getTime();
    if (epoch >= 1704067200UL) {  // 2024-01-01
      time_t t = (time_t)epoch;
      struct tm tmv;
      gmtime_r(&t, &tmv);
      logPrintf("%04d-%02d-%02d %02d:%02d:%02d UTC\n",
           tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday,
           tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
      char l2[17];
      snprintf(l2, sizeof(l2), "%04d-%02d-%02d %02d:%02d",
               tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday, tmv.tm_hour, tmv.tm_min);
      lcdui::show("Horloge UTC", l2);
      return true;
    }
    Serial.print(".");
    delay(500);
  }
  Serial.println("\n[NTP] heure indisponible — le contrôle du certificat serveur échouera");
  return false;
}


static bool generateKeyAndCsr() {
  lcdui::show("Clé P-256", "génération...");
  if (!SecureElement.begin()) {
    Serial.println("[clé] secure element logiciel indisponible (firmware ESP32-S3 trop ancien ?)");
    return false;
  }

  // Nouvelle paire P-256 à chaque démarrage, générée et signée dans l'ESP32-S3.
  ECP256Certificate csr;
  csr.begin();
  // Le serveur ignore ce CN et impose le nom approuvé.
  csr.setSubjectCommonName("pending");
  if (!SElementCSR::build(SecureElement, csr, KEY_SLOT, true)) {
    Serial.println("[clé] génération de la clé ou signature du CSR impossible");
    return false;
  }
  String pem = csr.getCSRPEM();
  if (pem.length() == 0 || pem.length() + 1 > sizeof(csrPem)) {
    logPrintf("[clé] CSR vide ou trop long (%u)\n", (unsigned)pem.length());
    return false;
  }
  memcpy(csrPem, pem.c_str(), pem.length() + 1);

  // Empreinte : SHA-256 du SubjectPublicKeyInfo DER, comme côté serveur.
  byte xy[64];
  if (!SecureElement.generatePublicKey(KEY_SLOT, xy)) {
    Serial.println("[clé] lecture de la clé publique impossible");
    return false;
  }
  static const byte SPKI_P256_PREFIX[] = {
    0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02, 0x01,
    0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00, 0x04
  };
  byte spki[sizeof(SPKI_P256_PREFIX) + 64];
  memcpy(spki, SPKI_P256_PREFIX, sizeof(SPKI_P256_PREFIX));
  memcpy(spki + sizeof(SPKI_P256_PREFIX), xy, 64);
  byte hash[32];
  if (!SecureElement.SHA256(spki, sizeof(spki), hash)) {
    Serial.println("[clé] SHA-256 impossible");
    return false;
  }
  for (int i = 0; i < 32; i++) {
    snprintf(fingerprint + i * 2, 3, "%02x", hash[i]);
  }
  fingerprint[64] = '\0';

  Serial.println("═══════════════════════════════════════");
  Serial.println("  DEMANDE D'ENRÔLEMENT");
  logPrintf("  nom       : %s\n", DEVICE_NAME);
  logPrintf("  empreinte : %s\n", fingerprint);
  logPrintf("  clé P-256 dans l'ESP32-S3 (emplacement %d), non affichée\n", KEY_SLOT);
  Serial.println("  Lisez l'empreinte à l'administrateur.");
  Serial.println("═══════════════════════════════════════");
  return true;
}


static bool httpExchange(const char* method, const char* path, const String& body, int& status, const char*& response) {
  WiFiSSLClient client;
  client.setCACert(ENROLL_CA_PEM);
  if (!client.connect(ENROLL_HOST, ENROLL_PORT)) {
    logPrintf("[HTTP] %s:%d injoignable ou certificat serveur refusé\n", ENROLL_HOST, ENROLL_PORT);
    lastHttpOk = false;
    client.stop();
    return false;
  }

  String head = String(method) + " " + path + " HTTP/1.0\r\nHost: " + ENROLL_HOST +
                "\r\nConnection: close\r\n";
  if (body.length() > 0) {
    head += "Content-Type: application/json\r\nContent-Length: " + String(body.length()) + "\r\n";
  }
  head += "\r\n";
  // Chaque write est une commande AT vers l'ESP32-S3 : on envoie par blocs.
  client.write((const uint8_t*)head.c_str(), head.length());
  if (body.length() > 0) {
    client.write((const uint8_t*)body.c_str(), body.length());
  }

  size_t len = 0;
  unsigned long start = millis();
  while (millis() - start < 20000) {
    int n = client.available();
    if (n > 0) {
      if (len + (size_t)n >= sizeof(rx)) {
        client.stop();
        Serial.println("[HTTP] réponse trop grande");
        return false;
      }
      int got = client.read((uint8_t*)rx + len, (size_t)n);
      if (got > 0) {
        len += (size_t)got;
        start = millis();
      }
      continue;
    }
    if (!client.connected()) {
      break;
    }
    delay(10);
  }
  client.stop();
  rx[len] = '\0';

  char* split = strstr(rx, "\r\n\r\n");
  if (split == nullptr || strncmp(rx, "HTTP/", 5) != 0) {
    Serial.println("[HTTP] réponse illisible");
    return false;
  }
  const char* sp = strchr(rx, ' ');
  status = (sp != nullptr) ? atoi(sp + 1) : 0;
  response = split + 4;
  lastHttpOk = true;
  return true;
}


// Arrêt définitif jusqu'au prochain RESET, avec la raison sur l'afficheur.
static void haltWith(const char* title, const char* why) {
  state = ST_REJECTED;
  ledOn = false;
  digitalWrite(LED_PIN, LOW);
  lcdui::show(title, why);
}


static void becomeRejected(const char* why) {
  logPrintf("[enrôlement] REFUSÉ — %s\n", why);
  Serial.println("  Appuyez sur RESET pour générer une nouvelle clé.");
  char l2[lcdui::TEXT_MAX + 1];
  snprintf(l2, sizeof(l2), "%s - RESET", why);
  haltWith("REFUSÉ", l2);
}


static bool connectMqtt() {
  lcdui::show("MQTT connexion", mqttHost);
  mqtt.disconnect();
  net.stop();
  net.setCACert(caPem);
  // Certificat DER fourni par le serveur + clé restée dans l'ESP32-S3.
  net.setEccSlot(KEY_SLOT, certDer, (int)certDerLen);
  mqtt.setServer(mqttHost, mqttPort);
  mqtt.setCallback(onMqttMessage);
  mqtt.setBufferSize(512);
  mqtt.setSocketTimeout(15);

  String will = String("{\"online\":false,\"device_id\":\"") + deviceId + "\"}";
  String clientId = String("r4-") + deviceId;
  bool ok = mqtt.connect(clientId.c_str(), topicStatus, 1, true, will.c_str());
  if (!ok) {
    logPrintf("[MQTT] échec (état %d)\n", mqtt.state());
    lcdui::showf("MQTT échec", "état %d, retry", mqtt.state());
    return false;
  }
  if (!mqtt.subscribe(topicCmd, 1)) {
    Serial.println("[MQTT] abonnement commande refusé");
    lcdui::show("MQTT échec", "abonnement cmd");
    return false;
  }
  String online = String("{\"online\":true,\"device_id\":\"") + deviceId + "\"}";
  mqtt.publish(topicStatus, online.c_str(), true);
  state = ST_ACTIVE;
  ledOn = true;
  digitalWrite(LED_PIN, HIGH);
  Serial.println("═══════════════════════════════════════");
  logPrintf("  CONNECTÉ  %s:%d\n", mqttHost, mqttPort);
  logPrintf("  identité  %s\n", deviceId);
  logPrintf("  pub       %s\n", topicTelemetry);
  logPrintf("  sub       %s\n", topicCmd);
  Serial.println("═══════════════════════════════════════");
  return true;
}


static bool takeBundle(JsonDocument& doc) {
  if (!copyText(doc["device_id"].as<const char*>(), deviceId, sizeof(deviceId), "device_id")) return false;
  if (strcmp(deviceId, DEVICE_NAME) != 0) {
    becomeRejected("device_id différent du nom demandé");
    return false;
  }
  const char* cert = doc["cert_pem"].as<const char*>();
  if (cert == nullptr || !pemToDer(cert, certDer, sizeof(certDer), certDerLen)) {
    logPrintf("[copie] certificat absent, illisible ou trop long (> %u octets DER)\n", (unsigned)CLIENT_CERT_DER_MAX);
    becomeRejected("certificat client inutilisable sur UNO R4 WiFi");
    return false;
  }
  if (!copyText(doc["ca_pem"].as<const char*>(), caPem, sizeof(caPem), "CA")) return false;
  if (!copyText(doc["mqtt"]["host"].as<const char*>(), mqttHost, sizeof(mqttHost), "hôte MQTT")) return false;
  mqttPort = doc["mqtt"]["port"].as<int>();
  if (mqttPort < 1 || mqttPort > 65535) {
    becomeRejected("port MQTT absent");
    return false;
  }
  if (!copyText(doc["mqtt"]["topics"]["telemetry"].as<const char*>(), topicTelemetry, sizeof(topicTelemetry), "telemetry")) return false;
  if (!copyText(doc["mqtt"]["topics"]["status"].as<const char*>(), topicStatus, sizeof(topicStatus), "status")) return false;
  if (!copyText(doc["mqtt"]["topics"]["cmd"].as<const char*>(), topicCmd, sizeof(topicCmd), "cmd")) return false;
  if (strstr(topicTelemetry, deviceId) == nullptr || strstr(topicStatus, deviceId) == nullptr ||
      strstr(topicCmd, deviceId) == nullptr) {
    becomeRejected("topics sans l'identité");
    return false;
  }
  const char* exp = doc["expires_at"].as<const char*>();
  if (exp == nullptr || !copyText(exp, expiresAt, sizeof(expiresAt), "expires_at")) {
    strcpy(expiresAt, "?");
  }
  lcdui::show("Approuvé", "certificat reçu");
  logPrintf("[enrôlement] approuvé, certificat de %u octets jusqu'à %s\n",
       (unsigned)certDerLen, exp ? exp : "?");
  state = ST_CONNECTING;
  lastPoll = millis();
  return connectMqtt();
}


static void handleDecision(int status, const char* response) {
  JsonDocument doc;
  if (deserializeJson(doc, response)) {
    Serial.println("[enrôlement] JSON illisible");
    return;
  }
  if (status == 409 || status == 400) {
    const char* err = doc["error"].as<const char*>();
    becomeRejected(err != nullptr ? err : "requête refusée");
    return;
  }
  const char* decision = doc["status"].as<const char*>();
  if (decision == nullptr) {
    Serial.println("[enrôlement] statut absent");
    return;
  }
  if (strcmp(decision, "pending") == 0) {
    Serial.println("[enrôlement] en attente de l'empreinte");
    return;
  }
  if (strcmp(decision, "rejected") == 0 || strcmp(decision, "revoked") == 0) {
    becomeRejected(decision);
    return;
  }
  if (strcmp(decision, "approved") == 0) {
    takeBundle(doc);
  }
}


static void sendRequest() {
  String payload;
  {
    JsonDocument body;
    body["name"] = DEVICE_NAME;
    body["csr_pem"] = csrPem;
    serializeJson(body, payload);
  }
  lcdui::show("Envoi du CSR", ENROLL_HOST);
  int status = 0;
  const char* response = nullptr;
  if (!httpExchange("POST", "/v1/enroll", payload, status, response)) {
    lcdui::show("Serveur injoign.", "nouvel essai 5 s");
    return;  // ST_BOOT : loop() retentera la demande
  }
  state = ST_AWAITING;
  handleDecision(status, response);
}


static void poll() {
  pollCount++;
  String path = String("/v1/enroll/") + fingerprint;
  int status = 0;
  const char* response = nullptr;
  if (!httpExchange("GET", path.c_str(), "", status, response)) {
    return;
  }
  handleDecision(status, response);
}


void onMqttMessage(char* topic, byte* payload, unsigned int length) {
  if (state != ST_ACTIVE || strcmp(topic, topicCmd) != 0) {
    return;
  }
  JsonDocument doc;
  if (deserializeJson(doc, payload, length)) {
    Serial.println("[cmd] JSON invalide");
    return;
  }
  if (!doc["led"].isNull()) {
    bool on = doc["led"].as<bool>();
    digitalWrite(LED_PIN, on ? HIGH : LOW);
    ledOn = on;
    Serial.println(on ? "[LED] ON" : "[LED] OFF");
  }
}


// Pages tournantes pour les états longs : attente d'approbation et session active.
// Les autres états affichent l'étape en cours au moment où elle se produit.
static void updatePages() {
  static State lastState = ST_BOOT;
  static unsigned long pageSince = 0;
  static unsigned long lastBuild = 0;
  static int page = 0;
  static char ipText[16] = "";
  static int rssi = 0;

  if (state != lastState) {
    lastState = state;
    page = 0;
    pageSince = millis();
    lastBuild = 0;
  }

  if (state == ST_AWAITING) {
    const int PAGES = 5;
    if (millis() - pageSince > 2500) {
      page = (page + 1) % PAGES;
      pageSince = millis();
    }
    if (page < 4) {
      // L'empreinte en 4 morceaux de 16 : l'administrateur compare morceau par morceau.
      char l1[17], l2[17];
      snprintf(l1, sizeof(l1), "Empreinte %d/4", page + 1);
      memcpy(l2, fingerprint + page * 16, 16);
      l2[16] = '\0';
      lcdui::show(l1, l2);
    } else if (lastHttpOk) {
      lcdui::showf("Attente admin", "%s v%lu", DEVICE_NAME, pollCount);
    } else {
      lcdui::show("Attente admin", "serveur injoign.");
    }
    return;
  }

  if (state == ST_ACTIVE) {
    const int PAGES = 4;
    if (millis() - pageSince > 3000) {
      page = (page + 1) % PAGES;
      pageSince = millis();
      lastBuild = 0;
    }
    // Les requêtes vers l'ESP32-S3 (IP, RSSI) passent par AT : une fois par page.
    if (lastBuild == 0) {
      lastBuild = millis();
      if (page == 1) rssi = WiFi.RSSI();
      if (page == 3) snprintf(ipText, sizeof(ipText), "%s", WiFi.localIP().toString().c_str());
    }
    int tenths = (int)(temperature * 10.0f + 0.5f);
    char l1[lcdui::TEXT_MAX + 1], l2[lcdui::TEXT_MAX + 1];
    switch (page) {
      case 0:
        snprintf(l1, sizeof(l1), "%s", deviceId);
        snprintf(l2, sizeof(l2), "%d.%d°C  env %lu", tenths / 10, tenths % 10, publishOk);
        break;
      case 1:
        snprintf(l1, sizeof(l1), "MQTT ok LED %s", ledOn ? "on" : "off");
        snprintf(l2, sizeof(l2), "WiFi %d dBm e%lu", rssi, publishFail);
        break;
      case 2:
        snprintf(l1, sizeof(l1), "Cert valide au");
        snprintf(l2, sizeof(l2), "%.16s", expiresAt);
        break;
      default:
        snprintf(l1, sizeof(l1), "IP %s", deviceId);
        snprintf(l2, sizeof(l2), "%s", ipText);
        break;
    }
    lcdui::show(l1, l2);
  }
}


void setup() {
  Serial.begin(115200);
  unsigned long t0 = millis();
  while (!Serial && millis() - t0 < 3000) {
  }
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  Serial.println("lab-secured-v3 (UNO R4 WiFi + LCD) — enrôlement par CSR");

  if (lcdui::begin()) {
    logPrintf("[LCD] 16x2 trouvé en 0x%02X\n", lcdui::address);
  } else {
    Serial.println("[LCD] aucun afficheur I2C — moniteur série seul");
  }
  lcdui::show("lab-secured-v3", "démarrage...");

  if (WiFi.status() == WL_NO_MODULE) {
    Serial.println("[WiFi] module ESP32-S3 injoignable.");
    haltWith("ARRÊT", "module WiFi absent");
    return;
  }
  if (!firmwareRecentEnough()) {
    haltWith("ARRÊT", "firmware ESP32 < 0.5.0 - mettre à jour");
    return;
  }

  if (!connectWiFi()) {
    Serial.println("[WiFi] réseau indisponible après plusieurs tentatives.");
    Serial.println("  Vérifiez arduino_secrets.h puis appuyez sur RESET.");
    haltWith("ARRÊT WiFi", "réseau indisponible - vérifier secrets - RESET");
    return;
  }

  if (!clockReady()) {
    becomeRejected("horloge non synchronisée");
    return;
  }
  if (!generateKeyAndCsr()) {
    becomeRejected("génération de clé impossible");
    return;
  }
  randomSeed(micros() ^ (uint32_t)WiFi.getTime());
  lastPoll = millis();
  sendRequest();
}


void loop() {
  lcdui::tick();
  if (state == ST_REJECTED) {
    delay(20);
    return;
  }
  // Le lien peut tomber pendant l'exécution. On le rétablit avant HTTP ou MQTT.
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] lien perdu — reconnexion");
    lcdui::show("WiFi perdu", "reconnexion...");
    if (!connectWiFi()) {
      delay(1000);
      return;
    }
    Serial.println("[WiFi] lien rétabli");
  }
  // La première demande a échoué (réseau, serveur) : on la renvoie.
  if (state == ST_BOOT && millis() - lastPoll > 5000) {
    lastPoll = millis();
    sendRequest();
  }
  if (state == ST_AWAITING && millis() - lastPoll > 3000) {
    lastPoll = millis();
    poll();
  }
  if (state == ST_CONNECTING && millis() - lastPoll > 3000) {
    lastPoll = millis();
    connectMqtt();
  }
  if (state == ST_ACTIVE) {
    if (!mqtt.connected()) {
      Serial.println("[MQTT] session coupée — nouvelle tentative (ACL, révocation ou lien)");
      lcdui::show("MQTT coupé", "ACL, révocation ou lien");
      state = ST_CONNECTING;
      lastPoll = millis();
      return;
    }
    mqtt.loop();
    if (millis() - lastTelemetry > 5000) {
      lastTelemetry = millis();
      temperature += (random(-5, 6) / 10.0f);
      if (temperature < 15.0f) temperature = 15.0f;
      if (temperature > 35.0f) temperature = 35.0f;
      char payload[96];
      // Pas de %f garanti dans la newlib-nano : dixièmes en entier (15..35 °C).
      int tenths = (int)(temperature * 10.0f + 0.5f);
      snprintf(payload, sizeof(payload), "{\"device_id\":\"%s\",\"temp_c\":%d.%d}",
               deviceId, tenths / 10, tenths % 10);
      if (!mqtt.publish(topicTelemetry, payload)) {
        publishFail++;
        Serial.println("[MQTT] publication non remise");
      } else {
        publishOk++;
        logPrintf("[TELEM] %d.%d °C\n", tenths / 10, tenths % 10);
      }
    }
  }
  updatePages();
}
