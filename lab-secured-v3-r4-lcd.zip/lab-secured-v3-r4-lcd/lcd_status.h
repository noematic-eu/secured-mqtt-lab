// Copyright (c) 2026 Baptiste Boussemart. Tous droits réservés.
// lcd_status.h — afficheur 16x2 I2C (HD44780 + PCF8574) pour lab-secured-v3.
//
// Câblage UNO R4 WiFi (bus Wire en 5 V, pas le Qwiic 3,3 V qui est Wire1) :
//   GND -> GND   VCC -> 5V   SDA -> SDA   SCL -> SCL   (broches près d'AREF)
// SDA/SCL et A4/A5 sont le même bus : l'un ou l'autre, même code.
// Pas de pull-up sur la carte : celles du module PCF8574 suffisent en général
// (sinon 4,7 kOhm vers 5 V). A4/A5 ne servent plus d'entrées analogiques.
//
// L'adresse est détectée au démarrage (PCF8574 : 0x20-0x27, PCF8574A : 0x38-0x3F).
// Sans afficheur, toutes les fonctions sont sans effet : le système fonctionne pareil.
//
// Le texte est en UTF-8 dans le sketch. La ROM du HD44780 n'a pas d'accents :
// é, è, à, ç... deviennent e, e, a, c ; ° devient le symbole degré de la ROM (0xDF).
// Une ligne de plus de 16 caractères défile.

#pragma once

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

namespace lcdui {

static const uint8_t COLS = 16;
static const uint8_t ROWS = 2;
static const size_t TEXT_MAX = 48;
static const unsigned long SCROLL_MS = 350;
static const int SCROLL_PAUSE_STEPS = 6;  // pause en début de ligne

static LiquidCrystal_I2C* lcd = nullptr;
static uint8_t address = 0;

static char text[ROWS][TEXT_MAX + 1];     // texte ASCII à afficher
static char shown[ROWS][COLS + 1];        // ce qui est réellement sur l'écran
static int offset[ROWS];
static int pause[ROWS];
static unsigned long lastScroll = 0;


static bool probe(uint8_t addr) {
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}


// UTF-8 -> jeu de caractères HD44780 (ROM A00).
static void toLcd(const char* src, char* dst, size_t dstMax) {
  size_t n = 0;
  const unsigned char* p = (const unsigned char*)(src ? src : "");
  while (*p != 0 && n < dstMax) {
    unsigned char c = *p;
    if (c < 0x80) {
      dst[n++] = (char)c;
      p++;
      continue;
    }
    if (c == 0xC2 && p[1] == 0xB0) {  // °
      dst[n++] = (char)0xDF;
      p += 2;
      continue;
    }
    if (c == 0xC3 && p[1] != 0) {
      unsigned char d = p[1];
      char r = '?';
      if (d >= 0xA0 && d <= 0xA5) r = 'a';
      else if (d == 0xA7) r = 'c';
      else if (d >= 0xA8 && d <= 0xAB) r = 'e';
      else if (d >= 0xAC && d <= 0xAF) r = 'i';
      else if (d >= 0xB2 && d <= 0xB6) r = 'o';
      else if (d >= 0xB9 && d <= 0xBC) r = 'u';
      else if (d >= 0x80 && d <= 0x85) r = 'A';
      else if (d == 0x87) r = 'C';
      else if (d >= 0x88 && d <= 0x8B) r = 'E';
      else if (d >= 0x8C && d <= 0x8F) r = 'I';
      else if (d >= 0x92 && d <= 0x96) r = 'O';
      else if (d >= 0x99 && d <= 0x9C) r = 'U';
      dst[n++] = r;
      p += 2;
      continue;
    }
    if (c == 0xE2 && p[1] == 0x80 && (p[2] == 0x93 || p[2] == 0x94)) {  // – —
      dst[n++] = '-';
      p += 3;
      continue;
    }
    // Autre séquence UTF-8 : un '?' pour toute la séquence.
    int len = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : 2;
    for (int i = 0; i < len && *p != 0; i++) p++;
    dst[n++] = '?';
  }
  dst[n] = '\0';
}


// Fenêtre de 16 caractères d'une ligne, avec défilement circulaire.
static void window(int row, char out[COLS + 1]) {
  const char* t = text[row];
  int len = (int)strlen(t);
  if (len <= COLS) {
    int i = 0;
    for (; i < len; i++) out[i] = t[i];
    for (; i < COLS; i++) out[i] = ' ';
  } else {
    const int gap = 3;
    int period = len + gap;
    for (int i = 0; i < COLS; i++) {
      int k = (offset[row] + i) % period;
      out[i] = (k < len) ? t[k] : ' ';
    }
  }
  out[COLS] = '\0';
}


static void render() {
  if (lcd == nullptr) return;
  for (int r = 0; r < ROWS; r++) {
    char w[COLS + 1];
    window(r, w);
    if (strcmp(w, shown[r]) != 0) {  // pas de clear() : pas de scintillement
      lcd->setCursor(0, r);
      for (int i = 0; i < COLS; i++) lcd->write((uint8_t)w[i]);
      memcpy(shown[r], w, COLS + 1);
    }
  }
}


// Retourne true si un afficheur a été trouvé.
static bool begin() {
  Wire.begin();
  Wire.setClock(100000);
  static const uint8_t common[] = { 0x27, 0x3F };
  for (uint8_t a : common) {
    if (probe(a)) { address = a; break; }
  }
  for (uint8_t a = 0x20; address == 0 && a <= 0x27; a++) if (probe(a)) address = a;
  for (uint8_t a = 0x38; address == 0 && a <= 0x3F; a++) if (probe(a)) address = a;
  if (address == 0) return false;

  lcd = new LiquidCrystal_I2C(address, COLS, ROWS);
  lcd->init();
  lcd->backlight();
  lcd->clear();
  for (int r = 0; r < ROWS; r++) {
    text[r][0] = '\0';
    memset(shown[r], ' ', COLS);
    shown[r][COLS] = '\0';
    offset[r] = 0;
    pause[r] = SCROLL_PAUSE_STEPS;
  }
  return true;
}


// Affiche deux lignes (UTF-8). Sans effet si le texte n'a pas changé :
// on peut l'appeler à chaque tour de loop() sans relancer le défilement.
static void show(const char* line1, const char* line2) {
  char a[TEXT_MAX + 1], b[TEXT_MAX + 1];
  toLcd(line1, a, TEXT_MAX);
  toLcd(line2, b, TEXT_MAX);
  const char* in[ROWS] = { a, b };
  bool changed = false;
  for (int r = 0; r < ROWS; r++) {
    if (strcmp(in[r], text[r]) != 0) {
      strcpy(text[r], in[r]);
      offset[r] = 0;
      pause[r] = SCROLL_PAUSE_STEPS;
      changed = true;
    }
  }
  if (changed) render();
}


// Variante avec format pour la seconde ligne.
static void showf(const char* line1, const char* fmt, ...) {
  char buf[TEXT_MAX + 1];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  show(line1, buf);
}


// À appeler souvent depuis loop() : fait défiler les lignes longues.
static void tick() {
  if (lcd == nullptr || millis() - lastScroll < SCROLL_MS) return;
  lastScroll = millis();
  for (int r = 0; r < ROWS; r++) {
    int len = (int)strlen(text[r]);
    if (len <= COLS) continue;
    if (pause[r] > 0) { pause[r]--; continue; }
    offset[r] = (offset[r] + 1) % (len + 3);
    if (offset[r] == 0) pause[r] = SCROLL_PAUSE_STEPS;
  }
  render();
}


}  // namespace lcdui
